#include<stdio.h>
 int main()
 {
         int n,i,a[10],min,j,temp;
         printf("Enter number of terms:  ");
         scanf("%d",&n);
         printf("Enter an array:  \n");

         for(i=0;i<n;i++)
         {
                 scanf("%d",&a[i]);
         }

         printf("The array is:  \n");

         for(i=0;i<n;i++)
         {
                 printf("%d\n",a[i]);
         }

                for(i=0;i<n-1;i++)
                {
                        min = i;
                        printf("min = %d",min);

				for(j=i+1;j<n;j++)
				{
					if(a[j]<a[min])
					{
						min = j;
						temp = a[i];
						a[i] = a[min];
						a[min] = temp;
					}
				}
                }
        printf("\nThe sorted array is: \n");
         for(i=0;i<n;i++)
         {
                 printf("%d\n",a[i]);
         }
 }
