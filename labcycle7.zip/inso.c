#include<stdio.h>
 int main()
 {
	 int n,i,a[10],key,j;
	 printf("Enter number of terms:  ");
	 scanf("%d",&n);
	 printf("Enter an array:  \n");
	 
	 for(i=0;i<n;i++)
	 {
		 scanf("%d",&a[i]);
	 }
	 
	 printf("The array is:  \n");
	 
	 for(i=0;i<n;i++)
         {
                 printf("%d\n",a[i]);
         }

	 	for(i=1;i<n;i++)
		{
			key = a[i];
			printf("Key = %d",key);
			j = i-1;
			while(j>=0 && a[j] > key)
			{
				a[j+1] = a[j];
				j = j-1;
			}
		a[j+1] = key;
		}
	printf("\nThe sorted array is: \n");
	 for(i=0;i<n;i++)
         {
                 printf("%d\n",a[i]);
         }
 }
