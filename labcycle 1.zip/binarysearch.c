#include<stdio.h>
#include<stdlib.h>
void main()
{
    int a[50],mid,end,beg,i,n,se,flag=0;
    printf("enter the limit \n");
    scanf("%d",&n);
    printf("\n enter the elemnents");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    printf("\n enter the search element");
    scanf("%d",se);
    while(beg<=end)
    {
        mid=(beg+end)/2;
        if(se==a[mid])
        {
            printf("\n element is found \n ");
            exit(0);
        }
        else
        {
            if (a[mid]<se)
            beg=mid+1;
            else
            end=mid-1;
        }
    }
    printf("\n element not found");
}